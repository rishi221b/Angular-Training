export class Login {
    name?: string;
    password?: string;
}
