export class User {
    id?:number;
    name?:string;
    password?:string;
    email?:string;
    location?:string;
    isBlocked?:boolean;
}
