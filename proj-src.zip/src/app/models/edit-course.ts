export class EditCourse {
}
