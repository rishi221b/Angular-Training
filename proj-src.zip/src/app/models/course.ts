export class Course {
    Course_Id?: number;
    Course_Name?: string;
    Course_Category?: string;
    Course_Price?: number;
    ImagePath?: string;
    Course_Description?: string;
}
