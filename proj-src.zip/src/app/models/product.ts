export class Product {
    id?: number;
    name? : string;
    rating?: number;
}
