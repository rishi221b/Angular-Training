import { EditCourse } from './edit-course';

describe('EditCourse', () => {
  it('should create an instance', () => {
    expect(new EditCourse()).toBeTruthy();
  });
});
