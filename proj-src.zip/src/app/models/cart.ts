export class Cart {
    cart_Id?: number;
    user_Id?: number;
    user_Name?: string;
    course_Name?: string;
    course_Price?: number;
    course_Description?: string;
    imgPath?: string;
    isBilled?: boolean;
}
